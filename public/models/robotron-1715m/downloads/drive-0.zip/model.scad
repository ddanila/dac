include <source/model.scad>
part="download-only";
teac_frame();
teac_mechanism();
teac_black();
teac_contacts();
teac_coils();
teac_power_socket();
teac_spindle();
teac_head();
teac_head_metal();
teac_clamp();
teac_components();
teac_cable_plug();
teac_boards(false);
teac_traces(false);
translate([231,203,-60]){drives(0);drive_insets(0);drive_latches(0);drive_led(0);}
