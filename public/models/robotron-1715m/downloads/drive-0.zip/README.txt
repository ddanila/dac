Robotron 1715M reference reconstruction: drive-0

model.stl is geometry only, in millimetres. Photos, materials, animation and
firmware are not part of STL. Drives use a local front-left-bottom origin;
boards retain the museum assembly coordinates. Open model.scad with OpenSCAD (Manifold backend)
to edit/rebuild it; all required included geometry sources are in source/.

Source: https://github.com/ddanila/3d-models/tree/main/models/robotron-1715m
Evidence and limitations: source/README.md
Drive references: owner photos PXL_20250212_094033966.jpg and
PXL_20250212_094038758.jpg, referenced in that documentation.
Board reconstruction: original Robotron W placement drawing and CRT schematic,
https://xepb.org/robotron/docs/1715w.zip , plus Danila’s owner solder-side photos.
See source/board-layout.json for evidence and estimated positions. Photos are not bundled.
Dimensions, hidden parts and linkage motion remain estimated. Not a validated
manufacturing model; parts may touch or remain separate within the STL.

Original modeling code: MIT (source/LICENSE).
Imported KiCad bodies, leads and footprint data retain their file-specific
licences and exceptions; see source/components/kicad/NOTICE.txt and source/.
The editable archive includes those original STEP files and licence texts.
