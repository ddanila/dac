# Keyboard review in OpenSCAD

Open [model.scad](model.scad) and press **F5**. This keyboard-only entry point
reuses the museum's canonical modules and key positions from `../model.scad`;
it does not copy the mechanical geometry into a separate model.

Use the Customizer's **Assembled**, **Exploded** or **Boards** preset, or change
`view` directly. `separation` controls the exploded spacing; zero restores the
assembled positions. Shell/deck/key/core/inlay/PCB/rubber colors are editable.
Clear keys have a separate silver inlay and configurable shell alpha.

- [Assembled preview](preview.png)
- [Low front preview](front.png)
- [Side profile](side.png)
- [Underside preview](underside.png)
- [Exploded preview with springs](exploded.png)
- [PCB/contact preview](boards.png)

Keep `show_springs=false` for quick exterior work; enable it to inspect mechanisms.
`draft=true` uses coarse spring tessellation. Key geometry retains the shared
model's tessellation. Hidden pale key cores are added in the exploded view.
The keyboard is centered locally, without the computer or monitor.

Legends are thin, flat **preview annotations**, not print geometry. They come from
`../keyboard-layout.json`; the helper below refreshes `legends.scad`. The default
`Arial Unicode MS` is installed on Danila's Mac and includes the special symbols.
Choose another installed Unicode font through `legend_font` on other computers.
No font files are distributed here. The browser retains its own curved legends.

From this directory:

```sh
python3 render.py --view assembled  # one quick color PNG
python3 render.py --view front      # check front fascia and deck joint
python3 render.py                   # all six review views
```

This uses the installed OpenSCAD build with the Manifold backend. On the current
Mac, all six previews take only a few seconds. It does not regenerate STLs,
rebuild the complete computer, sync DAC, or run browser/emulator CI. Review shape,
spacing, colors and internals here first; then export only the affected canonical
parts and sync the museum once the change is ready.

Edit shared mechanical dimensions in the parent SCAD files and `../keycap/` or
`../key-switch/`; edit key positions in `../tools/configure.py`, which generates both
`keyboard-layout.scad` and `keyboard-layout.json`, then refresh the preview legends. Colors changed here are review overrides: transfer approved
palette changes to the parent model/exporter before updating the museum.

OpenSCAD's [`color()`](https://files.openscad.org/documentation/manual/The_OpenSCAD_Language.html#color)
supports named colors, hexadecimal colors and RGBA transparency in F5 previews.
For example, `color("#202526") cap(...)` or `color([1,1,1,0.28]) cap(...)`.
STL does not carry color; keep the SCAD source and color PNGs for visual review.
Preview transparency is not a simulation of glass, metal reflection or rubber.
The assembled keyboard is a visual reference, not one printable part. Existing
photo-derived dimensions and hidden construction remain provisional.

The deck aperture is clipped behind the 1 mm front wall. Without this limit,
its tilted cutter removed the front fascia and exposed the PCB edge. The low
front preview checks that the shell closes beneath the deck.

Caps and SI/SO indicator lenses are included in the assembled and exploded views,
attached to their fixed deck carriers. `caps_led_on` and `siso_led_on` select static
lit colors; OpenSCAD does not simulate emitted light or emulator state. Both lenses
remain visible when off. Their positions and provisional 4 mm spherical shape
match the existing browser model; they were previously browser-only additions.
The shared full-machine SCAD assembly includes them too. Browser export still
leaves these separate lenses to the runtime, avoiding duplicate geometry.

The underside cable opening has two black rubber strips on its long edges,
as shown in owner photos `123247922` and `123319025`. A separate round grooved
bush holds the incoming lead in a folded support on the short edge toward the
controller. The controller overlaps the rear edge of the matrix PCB; its cable
end faces the opening. The brown bottom-cover insulating sheet is also modeled.
This v43 correction supersedes the earlier bare-edge and mirrored placement
interpretation. Exact mating depth remains estimated.

The light shell now ends at a straight, open lower rim above the separate bottom
lid, with six individual screw tabs. Inside photos `PXL_20261012_123048886.jpg`
and `PXL_20261012_123907435.jpg` establish this construction. The previous
spherical rounding rolled the shell underneath and is removed. Plan corner
bend radius is approximately 5 mm, while the top-to-wall bend is approximately
1 mm per owner feedback; tab dimensions and the 0.2 mm lid seam remain modeling estimates.
The light shell walls, sloped skin, rear ledge and lid tabs use the owner’s
approximately 1 mm sheet thickness. The separate bottom lid is also 1 mm thick, per owner confirmation.
The shell rim and mounting tabs sit at 1.2 mm, preserving the estimated 0.2 mm seam.

The black deck has a rolled top perimeter rather than a sharp extruded edge:
5 mm outer plan corners and a 5 mm outer top-edge radius, requested by the
owner as a visual trial after comparing photos `PXL_20261012_123006039.jpg` and `PXL_20261009_132919894.jpg`.
These black-deck radii are estimates, separate from the light sheet-metal shell’s
5 mm corner bends and approximately 1 mm top bend / sheet thickness.

Owner correction: the black deck is an open folded **1 mm sheet**, with a
uniform **8 mm** skirt height and a **1 mm** gap above the light base. Its top
and bottom planes are parallel (both follow the keyboard tilt); it is not a
wedge. The deck top and key mechanism datum stay in place while the skirt
extends downward. The light base is trimmed to the parallel seating plane.
The outer 5 mm / inner 4 mm bends preserve 1 mm material thickness.

The October 13 side photo `PXL_20261013_084425145.jpg` corrects the rear shelf:
the light base has one continuous sloping top plane, including behind the black
panel. The earlier raised rear ledge incorrectly intersected the black skirt.
The 1 mm separation now continues along the full panel; `--view side` checks it.

The same side photo shows a small round top-to-wall bend in the light base.
A 1 mm rounded offset of the inner wedge models this separately from the
5 mm corners in plan; the lower rim remains flat and open for the separate lid.

Owner profile correction: the light base rises from **15 mm at the front** to
**29 mm at the black panel’s rear edge**, then stays level at **29 mm** to the
back. `dimensions.scad` derives the panel tilt from those heights and the current
photo-fitted panel footprint. Keys and internal switch parts share the updated
height datum and tilt. The rear shelf and its pencil trough are horizontal.

The pencil groove is a closed pressed trough, not a through-hole. Its floor and
walls are 1 mm thick; the 2 mm recess depth remains a photo estimate.

## Accepted exterior baseline — 2026-10-13

Danila accepted the keyboard exterior at commit `cf7e113` as looking broadly
correct, including the black overlay’s 5 mm outer radii. Preserve this exterior
as the review baseline while refining internals. Internal board/mechanism detail
and provisional hidden dimensions still need further work; this is not approval
of the internals or a manufacturing-ready assembly.

The board/exploded presets include PCB supports, fasteners, short contact routes
and the underside socket on the stepped PCB tongue. The narrow controller keeps
its own pale laminate colour and separate grey/blue axial resistors. The socket
outline follows owner photos; its docking with the detached controller remains
unverified. No unobserved cable is added between them.

## Internal review — 2026-10-15

Owner 123622947 shows paired open holes at each narrow controller-board end.
The model now leaves them open instead of adding four unsupported screws. Hole
centres and diameters remain photo estimates; the visible cable clamp remains.
Owner 123103225 supplies the matrix connector's molded 2У0 marking. The broad
PCB and connector tongue have small rounded outside corners. These changes do
not alter the approved exterior. Existing support heights remain estimated.

The photos reviewed here show the underside, not bare switch contact faces.
The two isolated comb electrodes and their short routes therefore remain a
functional illustration, not a photo-traced contact pattern. No new hidden
controller-to-matrix connection or support is inferred from these photographs.
