include <source/model.scad>
part="download-only";
teac_frame();
teac_mechanism();
teac_black();
teac_contacts();
teac_coils();
teac_power_socket();
teac_spindle();
teac_head();
teac_head_metal();
teac_clamp();
teac_components();
teac_cable_plug();
teac_boards(true);
teac_traces(true);
translate([77,203,-60]){drives(1);drive_insets(1);drive_latches(1);drive_led(1);}
